# SHADOWTOOLS — Fabric 1.21.4

Krypton-inspired dark/purple/pink click GUI framework.

## Implemented in this source
- Right Shift opens the GUI.
- Category tabs: Combat, Render, World, Misc.
- Left-click toggles modules.
- Right-click a module row to open its settings.
- Alpha, Min Y, Max Y, Chest/Shulker/Spawner filter profile values can be changed.
- Module enabled states and settings persist in `.minecraft/config/shadowtools.json`.
- Enabled module names appear in a small HUD.
- GitHub Actions workflow builds the mod and uploads the JAR artifact.

## Important implementation status
This is a functional GUI/config/module framework, **not yet a complete Krypton-equivalent client**. The named SafeAnchor, CrystalMacro, ESP and chunk-finder entries are module profiles/placeholders; they do not yet perform world scanning, block rendering, anchor automation or crystal automation. Do not interpret a visible ON state as proof that those game mechanics are implemented.

Client-side inspection is limited to information the server sends to the client. There is no anti-cheat bypass or server-hidden chunk access.

## Build on GitHub
1. Extract this ZIP and upload all files/folders to a GitHub repository.
2. Open Actions and run `Build ShadowTools` (or push to `main`).
3. Download artifact `ShadowTools-Fabric-1.21.4`.
4. Install the generated JAR in `.minecraft/mods` with Fabric Loader 1.21.4 and Fabric API.

Requires Java 21.
