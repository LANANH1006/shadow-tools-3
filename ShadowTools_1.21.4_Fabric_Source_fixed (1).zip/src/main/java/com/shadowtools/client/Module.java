package com.shadowtools.client;

public final class Module {
    public final String name, description;
    public final Category category;
    public boolean enabled;
    public int keyCode;
    public float alpha = 0.72f;
    public int minY = -64, maxY = 320;
    public boolean chests = true, shulkers = true, spawners = true, barrels = true;
    public boolean settingMode = false;

    public Module(String name, String description, Category category, int keyCode) {
        this.name=name; this.description=description; this.category=category; this.keyCode=keyCode;
    }
    public void toggle() { enabled = !enabled; }
}
