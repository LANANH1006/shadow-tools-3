package com.shadowtools.client;
public enum Category { COMBAT, RENDER, WORLD, MISC }
